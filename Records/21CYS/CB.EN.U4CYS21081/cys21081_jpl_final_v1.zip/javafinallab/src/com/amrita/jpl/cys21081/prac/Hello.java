package com.amrita.jpl.cys21081.prac;

/**
 * @author Dinesh Reddy
 * @version 1.0
 */

/**
 * This class prints "Hello world!" to the console.
 */
public class Hello {
    /**
     * The main method is the entry point of the program.
     *
     * @param args the command-line arguments
     */
    public static void main(String[] args) {
        System.out.println("Hello world!");
    }
}
